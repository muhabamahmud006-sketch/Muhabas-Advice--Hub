// Add interactivity for future expansion
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    card.addEventListener('click', () => {
      alert('Stay motivated! Keep learning and growing.');
    });
  });
});
